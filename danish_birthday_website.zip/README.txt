DANISH BIRTHDAY WEBSITE

1. Upload the file "index.html" to a web host that gives you a public HTTPS link.
2. Open that public link on your phone to test it.
3. Use any QR-code generator to turn that public link into a QR code.
4. Danish scans the QR code -> the birthday website opens.

The website is already mobile-friendly and uses the lowercase birthday message you provided.
